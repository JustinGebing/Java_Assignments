public class Test{
    public static void main(String[] args) {
        System.out.println("My name is Justin Gebing.");
        System.out.println("I am 28 years old.");
        System.out.println("My hometown is Cincinnati, Ohio.");
    }
}